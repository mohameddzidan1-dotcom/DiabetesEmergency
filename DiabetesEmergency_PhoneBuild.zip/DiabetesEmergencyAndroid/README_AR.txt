مشروع تطبيق Diabetes Emergency

هذا مشروع Android Studio جاهز لبناء APK، وليس ملف APK مُجمّعًا بالفعل.

طريقة إنشاء APK:
1) نزّل وفك ضغط DiabetesEmergencyAndroid.zip على كمبيوتر.
2) افتح Android Studio واختر Open ثم اختر مجلد DiabetesEmergencyAndroid.
3) انتظر Gradle Sync. قد يحتاج Android Studio إلى تنزيل مكونات Android/Gradle لأول مرة.
4) من القائمة: Build > Build Bundle(s) / APK(s) > Build APK(s).
5) بعد انتهاء البناء اضغط Locate من إشعار Android Studio للعثور على app-debug.apk.
6) انقل APK إلى هاتف Android وثبّته. قد يطلب الهاتف السماح بالتثبيت من هذا المصدر.

اللعبة مدمجة داخل التطبيق وتعمل دون إنترنت بعد التثبيت.
ملاحظة: هذا إصدار تجريبي تعليمي. راجع المحتوى الطبي مع مختص قبل استخدامه في فعالية عامة.
